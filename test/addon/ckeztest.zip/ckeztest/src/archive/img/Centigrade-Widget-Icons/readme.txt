ZK widget icons created by
Centigrade GmbH, Germany
http://www.centigrade.de
Copyright 2008. All rights reserved.

Limited usage rights granted by Centigrade. Reselling of these icons is strictly prohibited. To use or redistribute icons in this folder please consult Centigrade GmbH for licensing details (www.centigrade.de).