zk.log('hello from script2.js');
