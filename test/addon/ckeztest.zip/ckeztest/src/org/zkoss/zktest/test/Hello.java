/* Hello.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Sat Jul  1 15:03:12     2006, Created by tomyeh
}}IS_NOTE

Copyright (C) 2006 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
}}IS_RIGHT
*/
package org.zkoss.zktest.test;

import org.zkoss.zk.ui.HtmlMacroComponent;

/**
 * Used to test with lang-addon.xml.
 *
 * @author tomyeh
 */
public class Hello extends HtmlMacroComponent {
}
