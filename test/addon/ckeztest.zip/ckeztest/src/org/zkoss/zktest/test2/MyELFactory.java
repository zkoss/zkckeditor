/* MyELFactory.java

{{IS_NOTE
	Purpose:
		
	Description:
		
	History:
		Tue Feb 12 15:35:30     2008, Created by tomyeh
}}IS_NOTE

Copyright (C) 2008 Potix Corporation. All Rights Reserved.

{{IS_RIGHT
	This program is distributed under GPL Version 3.0 in the hope that
	it will be useful, but WITHOUT ANY WARRANTY.
}}IS_RIGHT
*/
package org.zkoss.zktest.test2;

/**
 * Tests of using my own evaluator.
 *
 * @author tomyeh
 */
public class MyELFactory extends org.zkoss.xel.el.ELFactory {
	public MyELFactory() {
	}
}
